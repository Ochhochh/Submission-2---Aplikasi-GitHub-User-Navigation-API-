package com.example.submission2_mygithubapp.Ui

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.inputmethod.EditorInfo
import android.widget.TextView
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.submission2_mygithubapp.Model.ListUserAdapter
import com.example.submission2_mygithubapp.Model.MainViewModel
import com.example.submission2_mygithubapp.databinding.ActivityMainBinding


class MainActivity : AppCompatActivity() {
    private lateinit var binding : ActivityMainBinding
    private lateinit var viewModel: MainViewModel
    private lateinit var adapter: ListUserAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        viewModel = ViewModelProvider(this).get(MainViewModel::class.java)
        supportActionBar?.hide()

        //SearchUser
        binding.etSearch.setOnEditorActionListener(TextView.OnEditorActionListener { view, id, _ ->
        if(id == EditorInfo.IME_ACTION_SEARCH){
            val textSearch = view.text.toString()
            viewModel.setSearchUser(textSearch)
            Log.e("DataUser", textSearch)
            listDisplay()
            return@OnEditorActionListener true
        }
            return@OnEditorActionListener false
        })
    }

    private fun listDisplay(){
        viewModel.getSearchUser().observe(this) { user ->
            adapter = ListUserAdapter(user)
            binding.rvUser.adapter = adapter
            binding.rvUser.layoutManager = LinearLayoutManager(this)
            Log.e("DataUser", user.toString())
        }
    }
}